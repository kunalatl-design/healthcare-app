package com.example.healthcare;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DoctorActivity extends AppCompatActivity {
    EditText nameInput, dateInput;
    Button bookBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor);

        nameInput = findViewById(R.id.nameInput);
        dateInput = findViewById(R.id.dateInput);
        bookBtn = findViewById(R.id.bookBtn);

        bookBtn.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String date = dateInput.getText().toString().trim();
            if(name.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please fill both fields", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Appointment booked for " + name + " on " + date, Toast.LENGTH_LONG).show();
        });
    }
}
