package com.example.healthcare;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class TipsActivity extends AppCompatActivity {
    ListView tipsList;
    String[] tips = {
        "Drink plenty of water",
        "Exercise regularly",
        "Eat fruits and vegetables",
        "Sleep 7-8 hours daily",
        "Avoid junk food"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips);

        tipsList = findViewById(R.id.tipsList);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tips);
        tipsList.setAdapter(adapter);
    }
}
