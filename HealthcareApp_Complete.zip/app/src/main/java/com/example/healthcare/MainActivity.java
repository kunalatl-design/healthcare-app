package com.example.healthcare;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button doctorBtn, tipsBtn, bmiBtn, aboutBtn, logoutBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        doctorBtn = findViewById(R.id.doctorBtn);
        tipsBtn = findViewById(R.id.tipsBtn);
        bmiBtn = findViewById(R.id.bmiBtn);
        aboutBtn = findViewById(R.id.aboutBtn);
        logoutBtn = findViewById(R.id.logoutBtn);

        doctorBtn.setOnClickListener(v -> startActivity(new Intent(this, DoctorActivity.class)));
        tipsBtn.setOnClickListener(v -> startActivity(new Intent(this, TipsActivity.class)));
        bmiBtn.setOnClickListener(v -> startActivity(new Intent(this, BMICalculatorActivity.class)));
        aboutBtn.setOnClickListener(v -> startActivity(new Intent(this, AboutActivity.class)));
        logoutBtn.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}
