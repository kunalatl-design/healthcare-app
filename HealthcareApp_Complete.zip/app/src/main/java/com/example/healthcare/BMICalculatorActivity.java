package com.example.healthcare;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BMICalculatorActivity extends AppCompatActivity {
    EditText weightInput, heightInput;
    TextView resultText;
    Button calcBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);

        weightInput = findViewById(R.id.weightInput);
        heightInput = findViewById(R.id.heightInput);
        resultText = findViewById(R.id.resultText);
        calcBtn = findViewById(R.id.calcBtn);

        calcBtn.setOnClickListener(v -> {
            String wStr = weightInput.getText().toString();
            String hStr = heightInput.getText().toString();
            if (!wStr.isEmpty() && !hStr.isEmpty()) {
                try {
                    float weight = Float.parseFloat(wStr);
                    float height = Float.parseFloat(hStr) / 100f;
                    float bmi = weight / (height * height);
                    resultText.setText("Your BMI: " + String.format("%.1f", bmi));
                } catch (NumberFormatException e) {
                    resultText.setText("Enter valid numbers");
                }
            } else {
                resultText.setText("Please enter weight and height!");
            }
        });
    }
}
